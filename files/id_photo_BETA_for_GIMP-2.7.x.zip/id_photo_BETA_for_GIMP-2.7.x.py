#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GIMP id photo
# Copyright (c) 2011 Alexandr Karabanov
# zend.karabanov@gmail.com

# Фото на документы в GIMP
# (c) 2011 Александр Карабанов
# zend.karabanov@gmail.com

# ---------------------------------------------------------------------

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Эта программа является свободным программным обеспечением:
# вы можете распространять её и/или модифицировать
# в соответствии с условиями лицензии GNU General Public License версии 3
# либо (по вашему выбору) любой более поздней версии, опубликованной
# Free Software Foundation.

# Эта программа распространяется в надежде на то, что она будет полезной,
# но БЕЗ КАКИХ-ЛИБО ГАРАНТИЙ, вы используете её на свой СТРАХ и РИСК.
# Прочтите GNU General Public License для более подробной информации.

# Вы должны были получить копию GNU General Public License
# вместе с этой программой. Если нет, см. <http://www.gnu.org/licenses/>.


from gimpfu import *
from UserDict import UserDict
import gimpplugin
import gobject
import gtk
import pygtk
pygtk.require('2.0')

class configs(UserDict):

  # Проверка на наличие файла os.path.exists(path)
  
  def __init__(self, iniFile=gimp.directory.decode('utf-8') + "/plug-ins/formats.conf"):
    self.data = self._load_(iniFile)

  def _load_(self, iniFile, raw=True, vars=None):
    """Convert an INI file to a dictionary"""
    import ConfigParser
    config = ConfigParser.ConfigParser()
    config.read(iniFile)
    result = {}
    for section in config.sections():
      if section not in result:
        result[section] = {}
        for option in config.options(section):
          value = config.get(section, option, raw, vars)
          result[section][option] = value
    return result
    
  def dump(self, iniFile=gimp.directory.decode('utf-8') + "/plug-ins/formats.conf"):
    """Convert an dictionary to a INI file"""
    import ConfigParser
    config = ConfigParser.ConfigParser()
    config_dict = self.data
    for section, values in config_dict.items():
      config.add_section(section)
      for var_name, var_value in values.items():
        config.set(section, var_name, var_value)
    config.write(open(iniFile, "w"))

class id_photo_base(object):

  # Создаем экзмпляр класса configs с помощью методов которого
  # мы сможем работать с конфигом (получать данные, добавлять данные)
  formats = configs()

  def show_error_msg(self, msg):
    errdialog = gtk.MessageDialog(None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
    errdialog.set_position(gtk.WIN_POS_CENTER_ALWAYS)
    errdialog.show_all()
    response_err = errdialog.run()
    if response_err == gtk.RESPONSE_OK :
      errdialog.hide()
      errdialog.destroy()

  def info(self, msg):
    infodialog = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO, gtk.BUTTONS_OK, msg)
    infodialog.set_position(gtk.WIN_POS_CENTER_ALWAYS)
    infodialog.show_all()
    response_info = infodialog.run()
    if response_info == gtk.RESPONSE_OK :
      infodialog.hide()
      infodialog.destroy()

  # Странно... Параметр "image" передавать этой функции не надо.
  # Она, почему-то и так срабатывает...
  # Эта функция выполняется, когда пользователь выполняет двойной клик
  # над одним из пунктов списка форматов.
  # Написана для оптимизации временных затрат на выбор формата
  # и его применение путем нажатия кнопки "Применить"
  # Она является обёрткой для функции,
  # которая непосредственно кадрирует фото. Вероятно я её уберу после рефакторинга.
  def dubl_click_apply_format(self, widget, event, data=None):
    if event.button == 1 and event.type == gtk.gdk._2BUTTON_PRESS:
      # Скрываем окно, чтоб не мешало
      self.window.hide()
      ( model,path ) = self.treeview.get_selection().get_selected_rows()
      format_name =  model[path[0][0]][0]
      #self.info( "Двойной клик" )
      self.create_id_foto( self.image, self.formats.data[format_name] )
      gtk.main_quit()

  # Эта функция выполняется. когда пользователь нажимает кнопку "Применить"
  # в окне выбора формата. Она является обёрткой для функции,
  # которая непосредственно кадрирует фото. Вероятно я её уберу после рефакторинга.
  def apply_format(self, image, widget, data=None):
    # Скрываем окно, чтоб не мешало
    self.window.hide()
    # Мне стыдно, но я так и не понял до конца, как эта приблуда работает
    ( model,path ) = self.treeview.get_selection().get_selected_rows()
    format_name =  model[path[0][0]][0]
    #self.info( "Применяем формат: " + str( format_name ) )
    #self.info( "image = " + str( self.image ) )
    #self.info( "self.formats.data[format_name] возвращает = " + str( self.formats.data[format_name] ) )
    self.create_id_foto( self.image, self.formats.data[format_name] )
    gtk.main_quit()
      
  # Эта функция кадрирует фото в соответствии с переданым ей форматом.
  def create_id_foto(self, image, format):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    
    '''
    # В этом словаре хранятся размеры в миллиметрах
    # и соответствующие им размеры в пикселях (при разрешении 600ppi)
    size_mode = {'25': 591, '27': 638, '30': 709, '32': 756, '34': 804,
                 '40': 945, '35': 827, '36': 851, '45': 1063, '37': 875,
                 '47': 1111, '50': 1181, '51': 1205, '55': 1300,
                 '60': 1418, '80': 1890, '90': 2126, '120': 2835, '100': 2363,
                 '150': 3545,
                }
    '''
    
    # В этом словаре хранятся размеры в миллиметрах
    # и соответствующие им размеры в пикселях (при разрешении 300ppi)
    size_mode = {'25': 295, '27': 319, '30': 354, '32': 378, '34': 402,
                 '40': 473, '35': 414, '36': 426, '45': 532, '37': 437,
                 '47': 556, '50': 591, '51': 602, '55': 650,
                 '60': 709, '80': 945, '90': 1063, '120': 1418, '100': 1181,
                 '150': 1772,
                }

    # В этом списке хранятся координаты горионтальных направляющих
    hguide_list = []
    # В этом списке хранятся координаты вертикальных направляющих
    vguide_list = []
    # Находим направляющие, узнием их тип (вертикальная/горизонтальная)
    # и руководствуясь им заносим координаты в соответствующий список
    guide_id = 0
    guide_id = image.find_next_guide( guide_id )

    if guide_id == 0:
      self.info( "Нет ни одной направляющей. Поместите одну горизонтальную направляющую на уровне верхней частиголовы, одну горизонтальную напрвляющую на уровне глаз и одну на уровне подбородка, затем поставьте одну вертикальную направляющую на линию симметрии лица (порядок не важен, начинайте с любой направляющей)" )
      image.undo_group_end()
      gimp.quit()
    else:
      while guide_id != 0:
        if image.get_guide_orientation( guide_id ) == 0:
          hguide_list.append( image.get_guide_position( guide_id ) )
        else:
          vguide_list.append( image.get_guide_position( guide_id ) )
        guide_id = image.find_next_guide( guide_id )

    if len( hguide_list ) != 3:
      self.show_error_msg( "Горизонтальных направляющих должно быть три." )
      image.undo_group_end()
      gimp.quit()
    elif len( vguide_list ) < 1:
      self.show_error_msg( "Нет вертикальной направляющей." )
      image.undo_group_end()
      gimp.quit()
    elif len( vguide_list ) > 1:
      self.show_error_msg( "Должна быть только одна вертикальная направляющая." )
      image.undo_group_end()
      gimp.quit()

    # Пользователь может расставить направляющие в любой последовательности,
    # чтобы направляющие расположились в той последовательности, которая нужна нам
    # отсортируем список
    hguide_list.sort()

    #self.info( str( hguide_list[0] ) + "\n\n" + str( hguide_list[1] ) + "\n\n" +  str( hguide_list[2] ) )
    
    format["faceheight"] = int( format["faceheight"] )
    format["overheadheight"] = int( format["overheadheight"] )

    # Узнаем размер лицевой части головы
    # и руководствуясь им вычисляем размеры холста
    if format["onlyface"] == "True":
      k = hguide_list[2] - hguide_list[1] # Только лицо
      #self.info( "Нормальное: " + str( k ) )
    else:
      k = hguide_list[2] - hguide_list[0] # Вся голова
      #self.info( "Не нормальное: " + str( k ) )

    # Ширина холста
    w = round( ( int( format["width"] ) * k ) / format["faceheight"] )
    
    # Высота холста
    h = round( ( int( format["height"] ) * k ) / format["faceheight"] )

    # Расстояние на которое будет смещен холст по оси X
    x = ( w / 2 ) - vguide_list[0]

    # Расстояние на которое будет смещен холст по оси Y
    y = round( ( ( format["overheadheight"] * 12 ) * k ) / ( format["faceheight"] * 12 ) ) - hguide_list[0]

    #self.info( "ОТЛАДОЧНОЕ СООБЩЕНИЕ\n\n\n" + "k = " + str( k ) +"\nw = " + str( w ) + "\nh = " + str( h ) + "\nx = " + str( x ) + "\ny = " + str( y ))

    # Изменяем размер холста и смещаем его
    image.resize( int(w), int(h), int(x), int(y) )

    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на цвет индикатор
    gimp.set_background(113, 255, 0)
    # Сводим изображение
    image.flatten()
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Меняем разрешение до необходимого нам
    image.resolution = (300.0, 300.0)
    # Меняем размеры
    image.scale(size_mode[format["width"]], size_mode[format["height"]])

    # Удаляем все направляющие
    guide_id = 0
    guide_id = image.find_next_guide(guide_id)
    while guide_id != 0:
      image.delete_guide(guide_id)
      guide_id = image.find_next_guide(0)

    # Обновляем изоборажение на дисплее
    gimp.displays_flush()

    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  # Эта функция конвертирует цветное изображение в чёрнобелое
  def to_grayscale(self, image, drawable):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    # Конвертируем в оттенки серого пердварительно проверив надо ли конвертировать
    # иначе генерируется ошибка, что мол не надо конвертировать и так грэй-скэйл...
    if drawable.is_gray != True:
      pdb.gimp_image_convert_grayscale(image)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  # Эта функция добавляет серую однопиксельную рамку к изображению
  def gray_frame(self, image):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    # Увеличиваем размер холста
    image.resize(image.width + 2, image.height + 2, 1, 1)
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона
    gimp.set_background(125, 125, 125)
    # Сводим изображение.
    # После сведения идентификатор слоя drawable меняется, поэтому
    # присваиваем переменной self.drawable результат который возвращает image.flatten()
    # иначе словим ошибку "идентификатор drawable некорректен скорее всего вы пытаетесь
    # работать со слоем, которого не существует"
    self.drawable = image.flatten()
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
  # Эта функция добавляет овал с растушёвкой к изображению
  def oval(self, image, drawable):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    # Добавляем в изображение слой из которого будем делать овал с растушевкой
    if drawable.is_rgb:
      white_oval = gimp.Layer(image, "Овал с растушёвкой", drawable.width, drawable.height, RGBA_IMAGE, 100, NORMAL_MODE)
    else:
      self.info( "Овал с растушёвкой пока невозможно использовать для изображений в градациях серего.\nПереведите изображение в режим RGB" )
      image.undo_group_end()
      gimp.quit()
      
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Заливаем слой цветом фона
    white_oval.fill(BACKGROUND_FILL)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Встраиваем новый слой в изображение
    image.add_layer(white_oval, 0)
    
    # Включаем сглаживание
    pdb.gimp_context_set_antialias(True)
    # Включаем растушевку краёв
    pdb.gimp_context_set_feather(True)
    # Задаём радиус растушёвки краёв
    pdb.gimp_context_set_feather_radius( 95.0 , 95.0 )
    # Выделяем область в виде элипса в углу изображения
    pdb.gimp_image_select_ellipse( image,               # Идентификатор изображения
                                   CHANNEL_OP_REPLACE,  # Заменить текущее выделение
                                   ( white_oval.width * 0.1 ), # Кордината начальной точки выделения по оси X
                                   0, # Кордината начальной точки выделения по оси Y
                                  ( white_oval.width * 0.8 ),    # Ширина элипса
                                  ( white_oval.height * 0.9 )
                                 )

    # Удаляем ранее выделеную область
    pdb.gimp_edit_clear(white_oval)
    # Снимаем выделение
    pdb.gimp_selection_none(image)

    # Сводим изображение.
    # После сведения идентификатор слоя drawable меняется, поэтому
    # присваиваем переменной self.drawable результат который возвращает image.flatten()
    # иначе словим ошибку "идентификатор drawable некорректен скорее всего вы пытаетесь
    # работать со слоем, которого не существует"
    self.drawable = image.flatten()
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  # Эта функция добавляет "уголок" к изображению    
  def angle(self, image, drawable, type):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    if type == 'right_circular':
      # Включаем сглаживание
      pdb.gimp_context_set_antialias(True)
      # Включаем растушевку краёв
      pdb.gimp_context_set_feather(True)
      # Задаём радиус растушёвки краёв
      pdb.gimp_context_set_feather_radius( 2.0 , 2.0 )
      # Выделяем область в виде элипса в углу изображения
      pdb.gimp_image_select_ellipse(image,                # Идентификатор изображения
                                    CHANNEL_OP_REPLACE,   # Заменить текущее выделение
                                    (image.width - 220),  # Кордината начальной точки выделения по оси X
                                    (image.height - 173), # Кордината начальной точки выделения по оси Y
                                    540,                  # Ширина элипса
                                    540)                  # Высота элипса
                              
    elif type == 'left_circular':
      # Включаем сглаживание
      pdb.gimp_context_set_antialias(True)
      # Включаем растушевку краёв
      pdb.gimp_context_set_feather(True)
      # Задаём радиус растушёвки краёв
      pdb.gimp_context_set_feather_radius( 2.0 , 2.0 )
      pdb.gimp_image_select_ellipse(image,
                                    CHANNEL_OP_REPLACE,
                              -322,
                              (image.height - 177),
                              540,
                              540)

    elif type == 'right_direct':
      # Включаем сглаживание
      pdb.gimp_context_set_antialias(True)
      # Включаем растушевку краёв
      pdb.gimp_context_set_feather(True)
      # Задаём радиус растушёвки краёв
      pdb.gimp_context_set_feather_radius( 2.0 , 2.0 )
      points = [ image.width, (image.height - 169), # Координаты первой точки x1, y1
                 image.width, image.height,         # Координаты второй точки x2, y2
                 (image.width - 201), image.height ]# Координаты третьей точки x3, y3
      pdb.gimp_image_select_polygon(image,     # Идентификатор изображения
                                    CHANNEL_OP_REPLACE, # Заменить текущее выделение
                                    6,                  # Непонятный параметр
                                    points)             # Массив с точками через которые пройдет линия 
      
    elif type == 'left_direct':
      # Включаем сглаживание
      pdb.gimp_context_set_antialias(True)
      # Включаем растушевку краёв
      pdb.gimp_context_set_feather(True)
      # Задаём радиус растушёвки краёв
      pdb.gimp_context_set_feather_radius( 2.0 , 2.0 )
      points = [ 0, (image.height - 169),
                 0, image.height,
                 201, image.height ]
      pdb.gimp_image_select_polygon(image,
                                    CHANNEL_OP_REPLACE,
                                    6,
                                    points
                                   )
      
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Удаляем ранее выделеную область
    pdb.gimp_edit_clear(drawable)
    # Снимаем выделение
    pdb.gimp_selection_none(image)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  def print_functon(self, image, drawable, paper, copys, print_photo):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    # Изменяем размер холста до необходимых размеров
    if paper == "10x15":
      paper_width  = 1181
      paper_height = 1772
      
    if paper == "A5":
      paper_width  = 1748
      paper_height = 2480
      
    if paper == "A4":
      paper_width  = 2480
      paper_height = 3508
      
    # Изменяем размер холста до необходимых размеров
    image.resize(paper_width, paper_height, 0, 0)

    # Добавляем в изображение слой, который будет играть роль фона
    if drawable.is_rgb:
      white_bg = gimp.Layer(image, "Белый фон", paper_width, paper_height, RGB_IMAGE, 100, NORMAL_MODE)
    else:
      white_bg = gimp.Layer(image, "Белый фон", paper_width, paper_height, GRAY_IMAGE, 100, NORMAL_MODE)
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Заливаем слой цветом фона
    white_bg.fill(BACKGROUND_FILL)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Добавляем аьфа-канал
    white_bg.add_alpha()
    # Встраиваем новый слой в изображение
    image.add_layer(white_bg, 0)
    
    # Слой источник оказался внизу, поэтому переместим его наверх
    image.raise_layer_to_top(drawable)
    
    # Присвоис слою источнику адекватное имя
    drawable.name = "Фото"

    # Определяем каким будет пространство между фотографиями
    space = 20
    
    # Вычисляем размер слоя источника с учетом заданного ранее
    # пространства между фотографиями (размер слоя, естественно, ни как не изменяется физически)
    layer_new_width = drawable.width + space
    layer_new_height = drawable.height + space

    # Вычисляем сколько фоток по вертикали и горизонтали поместится
    # на заданном холсте
    w_count = paper_width / layer_new_width
    h_count = paper_height / layer_new_height
    
    # Вычисляем сколько фоток по вертикали и горизонтали поместится
    # на заданном холсте если перевернуть фото на 90°
    w_count_rotate = paper_width / layer_new_height
    h_count_rotate = paper_height / layer_new_width
    
    #self.info( "Перевёрнутых: " + str( w_count_rotate * h_count_rotate ) + "\n\nНе перевёрнутых: " + str( w_count_no_rotate * h_count_no_rotate ) )
    
    # Поворачиваем слой источник на 90° если это повысит плотность укладки
    if ( w_count_rotate * h_count_rotate ) > ( w_count * h_count ) :
      drawable.transform_rotate_simple( 0, 0, 0, 0 )
      # Слой источник сместился за пределы холста
      # Вернм его на место
      drawable.translate( drawable.width , 0 )
      # Ширинаи высота слоя источника поменялись местами
      # Вернём и их на место
      layer_new_width , layer_new_height = layer_new_height , layer_new_width
      # Количество фоток по вертикали и горизонтали поменялось
      # Исправим это
      w_count , h_count = w_count_rotate , h_count_rotate 
    
    # Вычисляем координаты точки отстчета
    x_fundamental = ( paper_width - ( layer_new_width * w_count ) ) / 2
    y_fundamental = ( paper_height - ( layer_new_height * h_count ) ) / 2
    # Позицианируем слой источник в точку отсчета, в этакое начало координат
    drawable.translate( x_fundamental , y_fundamental )
    
    # Инициируем счетчик, который будет отсчитывать текущее коичество фотографий на холсте
    # счетчик увеличивает своё значение с каждой итерацией цикла
    copys_counter = 0
    # Заполняем холст фотографиями
    # Для начала создадим группу слоёв которая объединит в себевсе фотографии
    layer_group = pdb.gimp_layer_group_new( image )
    layer_group.name = "Фотографии"
    image.add_layer(layer_group, 0)

    # w_count - количество фоток по гризонтали
    # h_count - количество фоток по вертикали
    for i in range( w_count ) :
      for j in range( h_count ) :
        # Если пользователь хочет напечатать больше фоток чем может поместиться на холсте,
        # то выходим из цикла при достижении максимального ( w_count * h_count ) числа копий,
        # которые могут поместиться на холсте.
        # Если пользователь хочет напечатать меньше фоток чем может поместиться нахолсте,
        # то выходим из цилкла при достижении этого числа фоток.
        if copys_counter == copys or copys_counter == ( w_count * h_count ) :
          break
        layer_new = drawable.copy()
        layer_new.name = "Фото"
        layer_new.add_alpha()
        image.insert_layer(layer_new, layer_group, 0)
        layer_new.translate( layer_new_width * i , layer_new_height * j )
        copys_counter += 1
    
    # Удаляем слой источник.
    # Он своё дело сделал и теперь может уйти
    image.remove_layer( drawable )
    
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()

    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
    # Сразу же печатаем изображение на дефолтном принтере
    # Если пользователь этого захотел
    if print_photo == True :
      pdb.file_print_gtk(image)
    
  # Эта функция только форпмирует конечный результат,
  # но на печаь его не выводит. Право вывести на печать
  # дается пользователю
  def compose_only(self, widget, data=None):
    #print "compose_only"
    
    # Скрываем окно, чтоб не мешало
    self.window.hide()
    
    if self.oval_check.get_active():
      self.oval(self.image, self.drawable)

    if self.border_check.get_active():
      self.gray_frame(self.image)
      
    if self.gray_check.get_active():
      self.to_grayscale(self.image, self.drawable)
      
    if self.angle_right_circular_radio.get_active():
      self.angle(self.image, self.drawable, 'right_circular')

    if self.angle_left_circular_radio.get_active():
      self.angle(self.image, self.drawable, 'left_circular')

    if self.angle_right_direct_radio.get_active():
      self.angle(self.image, self.drawable, 'right_direct')

    if self.angle_left_direct_radio.get_active():
      self.angle(self.image, self.drawable, 'left_direct')
      
    copys = self.copys_spin.get_value_as_int()
    paper = self.paper_cb.get_active_text()
    #resolution = "300"
    print_photo = False
    self.print_functon( self.image, self.drawable, paper, copys, print_photo )
    #self.info( "Происходит магия и конечный результат только формируется в размере " + copys + " копий " + "на бумаге формата " + paper)
    
    gtk.main_quit()

  # Эта функция делает тоже самое, что и "compose_only", но, ко всему прочему,
  # ещё и выводит изображение на дефолтный принтер
  def compose_and_print(self, widget, data=None):
    #print "message compose_and_print"
    # Скрываем окно, чтоб не мешало
    self.window.hide()
    #self.info("Происходит магия и конечный результат формируется и распечатывается на дефолтном принтере")
    
    if self.oval_check.get_active():
      self.oval(self.image, self.drawable)

    if self.border_check.get_active():
      self.gray_frame(self.image)
      
    if self.gray_check.get_active():
      self.to_grayscale(self.image, self.drawable)
      
    if self.angle_right_circular_radio.get_active():
      self.angle(self.image, self.drawable, 'right_circular')

    if self.angle_left_circular_radio.get_active():
      self.angle(self.image, self.drawable, 'left_circular')

    if self.angle_right_direct_radio.get_active():
      self.angle(self.image, self.drawable, 'right_direct')

    if self.angle_left_direct_radio.get_active():
      self.angle(self.image, self.drawable, 'left_direct')
      
    copys = self.copys_spin.get_value_as_int()
    paper = self.paper_cb.get_active_text()
    #resolution = "300"
    print_photo = True
    self.print_functon( self.image, self.drawable, paper, copys, print_photo )

    gtk.main_quit()

  # Эта функция способствует добавлению нового формата
  def add_format(self, widget, data=None):
    #print "message add_format"
    name = self.name_entry.get_text()
    width = str( self.width_spin.get_value_as_int() )
    height = str( self.height_spin.get_value_as_int() )
    faceheight = str( self.faceheight_spin.get_value_as_int() )
    overheadheight = str( self.overheadheight_spin.get_value_as_int() )
    if self.onlyface2_radio.get_active():
      onlyface = "True"
    else:
      onlyface = "False"

    if self.formats.data.has_key(name):
      self.show_error_msg("Формат с названием '" + name + "' уже существует.\n\nВыберите другое название.")
    else:
       # Скрываем окно, чтоб не мешало
       self.window.hide()
       self.formats.data[name] = {"width":width, "height":height, "faceheight":faceheight, "onlyface":onlyface, "overheadheight":overheadheight, "underheadheight":"0", "colored":"0"}
       self.formats.dump()
       #self.info("ОТЛАОЧНОЕ СООБЩЕНИЕ" + "\n\n" + "Всё готово. Формат добавлен." + "\n\n" + "Название: " + name + "\n\n" + "Ширина: " + width + "\n\n" + "Высота: " + height + "\n\n" + "Лицо: " + faceheight + "\n\n" + "Вся голова: " + onlyface + "\n\n" + "До головы: " + overheadheight)
       gtk.main_quit()

  # Вспомогательная функция. Выполняется при закрытии окна
  # или нажатии кнопки "Отмена"
  def delete_event(self, widget, event, data=None):
    #print "delete event occurend"
    return False

  # Вспомогательная функция. Выполняется при закрытии окна
  # или нажатии кнопки "Отмена"
  def destroy(self, widget, data=None):
    #print "destroy signal occurend"
    gtk.main_quit()

#########################################################
#-------- Тут и класса конец, а кто потомок молодец ----#
#########################################################


class select_format_id_photo(id_photo_base):
  def __init__(self, runmode, image):

    self.image = image
    #self.drawable = drawable
    
    # Инициируем список
    self.formats_list = gtk.ListStore(gobject.TYPE_STRING)

    # Добовляем в выпадающий список пункты
    # Каждый пункт соответствует ключу словаря содержащего в себе данные о форматах
    for format in self.formats.data.keys():
      self.formats_list.append( [format] )

    # Упаковываем все вышесказанное в красивый,
    # но непонятно как работающий виджет
    self.treeview = gtk.TreeView()
    self.treeview.set_model( self.formats_list )
    #self.column = gtk.TreeViewColumn( "Форматы фото" )
    self.column = gtk.TreeViewColumn()
    self.cell = gtk.CellRendererText()
    self.column.pack_start( self.cell )
    self.column.add_attribute( self.cell, 'text', 0 )
    self.treeview.append_column( self.column )
    # Навешиваем событие, чтобы по двойному клику выполнялась определенная функция
    self.treeview.add_events(gtk.gdk.BUTTON_PRESS_MASK )
    self.treeview.connect('button_press_event', self.dubl_click_apply_format)
    self.treeview.show()
    
    # Создаем кнопку "Отмена"
    self.cancel_button = gtk.Button(None, gtk.STOCK_CANCEL)
    self.cancel_button.connect_object("clicked", self.destroy, None)
    self.cancel_button.show()

    # Создаем кнопку "Применить"
    self.add_button = gtk.Button(None, gtk.STOCK_APPLY)
    self.add_button.connect("clicked", self.apply_format, None)
    self.add_button.show()
    
    # Пакуем кнопки "Отмена" и  "Применить"
    self.button_box = gtk.HButtonBox()
    self.button_box.set_layout(gtk.BUTTONBOX_EDGE)
    self.button_box.set_spacing(10)
    self.button_box.add(self.cancel_button)
    self.button_box.add(self.add_button)
    self.button_box.show()
    
    # Пакуем все
    self.all_widget_vbox = gtk.VBox(False, 10)
    self.all_widget_vbox.pack_start(self.treeview, False, False, 0)
    #self.all_widget_vbox.pack_start(self.table, False, False, 0)
    self.all_widget_vbox.pack_start(self.button_box, False, False, 0)
    self.all_widget_vbox.show()

    # Создаем окно. Добавляем всё к окну и показываем его
    self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    self.window.set_position(gtk.WIN_POS_CENTER_ALWAYS)
    self.window.set_title("Выберите формат")
    #self.window.set_size_request(250, 770)
    self.window.set_border_width(5)
    self.window.set_resizable(False)
    self.window.connect("delete_event", self.delete_event)
    self.window.connect("destroy", self.destroy)
    self.window.add(self.all_widget_vbox)
    self.window.show()
    gtk.main()

class dump_config(id_photo_base):
  def __init__(self, runmode, image):
    #self.dumpcfg()
    # Создаем виджеты
    self.name_label = gtk.Label("Название формата:")
    self.name_label.set_justify(gtk.JUSTIFY_LEFT)
    self.name_label.show()

    self.width_label = gtk.Label("Ширина фото:")
    self.width_label.set_justify(gtk.JUSTIFY_LEFT)
    self.width_label.show()

    self.height_label = gtk.Label("Высота фото: ")
    self.height_label.set_justify(gtk.JUSTIFY_LEFT)
    self.height_label.show()

    self.overheadheight_label = gtk.Label("До головы:     ")
    self.overheadheight_label.set_justify(gtk.JUSTIFY_LEFT)
    self.overheadheight_label.show()

    self.name_entry = gtk.Entry()
    self.name_entry.grab_focus()
    self.name_entry.show()

    self.width_adj = gtk.Adjustment(0.0, 0.0, 200.0, 1.0, 1.0, 0.0)
    self.width_spin = gtk.SpinButton(self.width_adj, 0, 0)
    self.width_spin.set_numeric(True)
    self.width_spin.show()
    
    self.height_adj = gtk.Adjustment(0.0, 0.0, 200.0, 1.0, 1.0, 0.0)
    self.height_spin = gtk.SpinButton(self.height_adj, 0, 0)
    self.height_spin.set_numeric(True)
    self.height_spin.show()

    self.overheadheight_adj = gtk.Adjustment(0.0, 0.0, 200.0, 1.0, 1.0, 0.0)
    self.overheadheight_spin = gtk.SpinButton(self.overheadheight_adj, 0, 0)
    self.overheadheight_spin.set_numeric(True)
    self.overheadheight_spin.show()

    # Создаем кнопку "Отмена"
    self.cancel_button = gtk.Button(None, gtk.STOCK_CANCEL)
    self.cancel_button.connect_object("clicked", self.destroy, None)
    self.cancel_button.show()

    # Создаем кнопку "Добавить"
    self.add_button = gtk.Button(None, gtk.STOCK_ADD)
    self.add_button.connect("clicked", self.add_format, None)
    self.add_button.show()

    # Пакуем виджеты в горизонтальный бокс
    self.name_hbox = gtk.HBox(False, 10)
    self.name_hbox.pack_start(self.name_label, False, False, 0)
    self.name_hbox.pack_start(self.name_entry, True, True, 0)
    self.name_hbox.show()

    # Пакуем виджеты в горизонтальный бокс
    self.width_hbox = gtk.HBox(False, 0)
    self.width_hbox.pack_start(self.width_label, True, True, 0)
    self.width_hbox.pack_start(self.width_spin, False, False, 5)
    self.width_hbox.show()

    # Пакуем виджеты в горизонтальный бокс
    self.height_hbox = gtk.HBox(False, 0)
    self.height_hbox.pack_start(self.height_label, True, True, 0)
    self.height_hbox.pack_start(self.height_spin, False, False, 5)
    self.height_hbox.show()

    # Пакуем виджеты в горизонтальный бокс
    self.overheadheight_hbox = gtk.HBox(False, 0)
    self.overheadheight_hbox.pack_start(self.overheadheight_label, True, True, 0)
    self.overheadheight_hbox.pack_start(self.overheadheight_spin, False, False, 5)
    self.overheadheight_hbox.show()

    # Пакуем в вертикальный бокс горизонтальные боксы с виджетами
    self.size_vbox = gtk.VBox(True, 0)
    self.size_vbox.pack_start(self.width_hbox, True, True, 0)
    self.size_vbox.pack_start(self.height_hbox, True, True, 0)
    self.size_vbox.pack_start(self.overheadheight_hbox, True, True, 0)
    self.size_vbox.show()

    self.onlyface1_radio = gtk.RadioButton(None, "от глаз до подбородка")
    self.onlyface1_radio.show()

    self.onlyface2_radio = gtk.RadioButton(self.onlyface1_radio, "от макушки до подбородка")
    self.onlyface2_radio.show()

    self.faceheight_adj = gtk.Adjustment(0.0, 0.0, 200.0, 1.0, 1.0, 0.0)
    self.faceheight_spin = gtk.SpinButton(self.faceheight_adj, 0, 0)
    self.faceheight_spin.set_numeric(True)
    self.faceheight_spin.show()

    self.faceheight_table = gtk.Table(3, 1, False)
    self.faceheight_table.set_border_width(5)
    self.faceheight_table.set_row_spacings(5)
    self.faceheight_table.set_col_spacings(0)
    self.faceheight_table.attach(self.faceheight_spin, 0, 1, 0, 1)
    self.faceheight_table.attach(self.onlyface1_radio, 0, 1, 1, 2)
    self.faceheight_table.attach(self.onlyface2_radio, 0, 1, 2, 3)
    self.faceheight_table.show()

    self.faceheight_frame = gtk.Frame("Размер лицевой части головы")
    self.faceheight_frame.set_border_width(0)
    self.faceheight_frame.add(self.faceheight_table)
    self.faceheight_frame.show()
    # Конец особая магия для "Лицевая чпасть головы" %-)

    # Пакуем кнопки "Отмена" и  "Добавить"
    self.button_box = gtk.HButtonBox()
    self.button_box.set_layout(gtk.BUTTONBOX_END)
    self.button_box.set_spacing(10)
    self.button_box.add(self.cancel_button)
    self.button_box.add(self.add_button)
    self.button_box.show()

    # Инициируем таблицу, в которую поместим все виджеты
    self.table = gtk.Table(2, 2, False)
    self.table.set_border_width(0)
    self.table.set_row_spacings(0)
    self.table.set_col_spacings(10)
    self.table.attach(self.size_vbox, 0, 1, 0, 1)
    self.table.attach(self.faceheight_frame, 1, 2, 0, 1)
    self.table.show()

    # Пакуем все
    self.all_widget_vbox = gtk.VBox(False, 10)
    self.all_widget_vbox.pack_start(self.name_hbox, False, False, 0)
    self.all_widget_vbox.pack_start(self.table, False, False, 0)
    self.all_widget_vbox.pack_start(self.button_box, False, False, 0)
    self.all_widget_vbox.show()

    # Создаем окно. Добавляем всё к окну и показываем его
    self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    self.window.set_position(gtk.WIN_POS_CENTER_ALWAYS)
    self.window.set_title("Добавить формат")
    self.window.set_size_request(450, 200)
    self.window.set_border_width(5)
    self.window.set_resizable(False)
    self.window.connect("delete_event", self.delete_event)
    self.window.connect("destroy", self.destroy)
    self.window.add(self.all_widget_vbox)
    self.window.show()
    gtk.main()

class print_photo(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable

    # Создаем виджеты
    self.gray_check = gtk.CheckButton("обесцветить фото")
    self.gray_check.show()

    self.border_check = gtk.CheckButton("добавить рамку")
    self.border_check.show()
    
    self.oval_check = gtk.CheckButton("добавить овал с растушёвкой")
    self.oval_check.show()

    # Уголки
    self.angle_none_radio = gtk.RadioButton(None, "без уголка")
    self.angle_none_radio.show()

    self.angle_right_circular_radio = gtk.RadioButton(self.angle_none_radio, "круглый справа")
    self.angle_right_circular_radio.show()

    self.angle_left_circular_radio = gtk.RadioButton(self.angle_right_circular_radio, "круглый слева")
    self.angle_left_circular_radio.show()

    self.angle_right_direct_radio = gtk.RadioButton(self.angle_left_circular_radio, "прямой справа")
    self.angle_right_direct_radio.show()

    self.angle_left_direct_radio = gtk.RadioButton(self.angle_right_direct_radio, "прямой слева")
    self.angle_left_direct_radio.show()

    # Количество фоток
    self.copys_adj = gtk.Adjustment(4.0, 0.0, 200.0, 1.0, 1.0, 0.0)
    self.copys_spin = gtk.SpinButton(self.copys_adj, 0, 0)
    self.copys_spin.set_numeric(True)
    self.copys_spin.show()

    self.copys_label = gtk.Label("фото на листе")
    self.copys_label.set_justify(gtk.JUSTIFY_LEFT)
    self.copys_label.show()
    
    # Выпадающий сисок "Формат бумаги"
    self.paper_cb = gtk.combo_box_new_text()
    self.paper_cb.append_text("10x15")
    self.paper_cb.append_text("A5")
    self.paper_cb.append_text("A4")
    self.paper_cb.set_active(0)
    self.paper_cb.show()

    # Создаем кнопку "Отмена"
    self.cancel_button = gtk.Button(None, gtk.STOCK_CANCEL)
    self.cancel_button.connect_object("clicked", self.destroy, None)
    self.cancel_button.show()

    # Создаем кнопку "Напечатать"
    self.print_button = gtk.Button(None, gtk.STOCK_PRINT)
    self.print_button.connect("clicked", self.compose_and_print, None)
    self.print_button.show()

    # Создаем кнопку "Применить"
    self.apply_button = gtk.Button(None, gtk.STOCK_APPLY)
    self.apply_button.connect("clicked", self.compose_only, None)
    self.apply_button.show()

    # Пакуем виджеты в горизонтальный бокс
    self.copys_hbox = gtk.HBox(False, 0)
    self.copys_hbox.pack_start(self.copys_spin, False, False, 0)
    self.copys_hbox.pack_start(self.copys_label, False, False, 5)
    self.copys_hbox.pack_start(self.paper_cb, False, False, 0)
    self.copys_hbox.show()

    # Пакуем опции в вертикальный бокс
    self.options_vbox = gtk.VBox(False, 5)
    self.options_vbox.pack_start(self.copys_hbox, False, False, 5)
    self.options_vbox.pack_start(self.gray_check, False, False, 5)
    self.options_vbox.pack_start(self.border_check, False, False, 5)
    self.options_vbox.pack_start(self.oval_check, False, False, 5)
    self.options_vbox.show()

    # Пакуем уголки в вертикальный бокс
    self.angle_table = gtk.Table(5, 1, False)
    self.angle_table.set_border_width(5)
    self.angle_table.set_row_spacings(5)
    self.angle_table.set_col_spacings(0)
    self.angle_table.attach(self.angle_none_radio, 0, 1, 0, 1)
    self.angle_table.attach(self.angle_right_circular_radio, 0, 1, 1, 2)
    self.angle_table.attach(self.angle_left_circular_radio, 0, 1, 2, 3)
    self.angle_table.attach(self.angle_right_direct_radio, 0, 1, 3, 4)
    self.angle_table.attach(self.angle_left_direct_radio, 0, 1, 4, 5)
    self.angle_table.show()

    # Фрейм для уголка
    self.angle_frame = gtk.Frame("Добавить уголок")
    self.angle_frame.set_border_width(0)
    self.angle_frame.add(self.angle_table)
    self.angle_frame.show()

    # Инициируем таблицу, в которую поместим все виджеты
    self.table = gtk.Table(2, 2, False)
    self.table.set_border_width(0)
    self.table.set_row_spacings(0)
    self.table.set_col_spacings(0)
    self.table.attach(self.options_vbox, 0, 1, 0, 1)
    self.table.attach(self.angle_frame, 1, 2, 0, 1)
    self.table.show()

    # Пакуем кнопки "Отмена" и  "Применить" и "Печать"
    self.button_box = gtk.HButtonBox()
    self.button_box.set_layout(gtk.BUTTONBOX_EDGE)
    self.button_box.set_spacing(10)
    self.button_box.add(self.cancel_button)
    self.button_box.add(self.print_button)
    self.button_box.add(self.apply_button)
    self.button_box.show()

    # Пакуем все
    self.all_widget_vbox = gtk.VBox(False, 5)
    self.all_widget_vbox.pack_start(self.table, False, False, 0)
    self.all_widget_vbox.pack_start(self.button_box, False, False, 0)
    self.all_widget_vbox.show()

    # Создаем окно. Добавляем всё к окну и показываем его
    self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    self.window.set_position(gtk.WIN_POS_CENTER_ALWAYS)
    self.window.set_title("Сформировать и распечатать")
    #self.window.set_size_request(400, 200)
    self.window.set_border_width(5)
    self.window.set_resizable(False)
    self.window.connect("delete_event", self.delete_event)
    self.window.connect("destroy", self.destroy)
    self.window.add(self.all_widget_vbox)
    self.window.show()
    gtk.main()


#########################################################
#--------           Вот оно - начало начал          ----#
#########################################################


class id_photo_plugin(gimpplugin.plugin):
  def start(self):
    gimp.main(self.init, self.quit, self.query, self._run)

  def init(self):
    pass

  def quit(self):
    pass

  def query(self):
    authorname = "Карабанов александр (zend.karabanov@gmail.com)"
    copyrightname = "Карабанов Александр"
    imgmenupath = "<Image>/На документы (BETA)/"
    date = "27 января 2011 года"

    select_format_id_photo_description = "Руководствуясь контрольными точками формирует фото на документы  формата 30x40."
    select_format_id_photo_help = "Расставьте направляющие и вызовите эту функцию."
    select_format_id_photo_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_select_format_id_photo",
      select_format_id_photo_description,
      select_format_id_photo_help,
      authorname,
      copyrightname,
      date,
      "%s_Формат... (BETA)" % (imgmenupath),
      "RGB*, GRAY*",
      PLUGIN,
      select_format_id_photo_params,
      []
    )

    dump_config_description = "Добавить новый формат."
    dump_config_help = "Вызовите эту функцию, чтобы добавить формат."
    dump_config_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_dump_config",
      dump_config_description,
      dump_config_help,
      authorname,
      copyrightname,
      date,
      "%s_Добавить формат... (BETA)" % (imgmenupath),
      "RGB*, GRAY*",
      PLUGIN,
      dump_config_params,
      []
    )

    print_photo_description = "Сформировать и напечать окончательный результат."
    print_photo_help = "Вызовите эту функцию, чтобы распечатать фото."
    print_photo_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_print_photo",
      print_photo_description,
      print_photo_help,
      authorname,
      copyrightname,
      date,
      "%s_Печать... (BETA)" % (imgmenupath),
      "RGB*, GRAY*",
      PLUGIN,
      print_photo_params,
      []
    )

  def python_select_format_id_photo(
    self,
    runmode,
    image
  ):
    select_format_id_photo(runmode, image)
    
  def python_dump_config(
    self,
    runmode,
    image
  ):
    dump_config(runmode, image)

  def python_print_photo(
    self,
    runmode,
    image,
    drawable
  ):
    print_photo(runmode, image, drawable)

if __name__ == "__main__":
  id_photo_plugin().start()

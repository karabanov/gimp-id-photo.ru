#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GIMP id photo
# Copyright (c) 2011 Alexandr Karabanov
# zend.karabanov@gmail.com

# Фото на документы в GIMP
# (c) 2011 Александр Карабанов
# zend.karabanov@gmail.com

# ---------------------------------------------------------------------

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Эта программа является свободным программным обеспечением:
# вы можете распространять её и/или модифицировать
# в соответствии с условиями лицензии GNU General Public License версии 3
# либо (по вашему выбору) любой более поздней версии, опубликованной
# Free Software Foundation.

# Эта программа распространяется в надежде на то, что она будет полезной,
# но БЕЗ КАКИХ-ЛИБО ГАРАНТИЙ, вы используете её на свой СТРАХ и РИСК.
# Прочтите GNU General Public License для более подробной информации.

# Вы должны были получить копию GNU General Public License
# вместе с этой программой. Если нет, см. <http://www.gnu.org/licenses/>.


from gimpfu import *
import gimpplugin, gtk

class id_photo_base(object):

  def show_error_msg(self, msg):
    errdialog = gtk.MessageDialog(None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
    errdialog.show_all()
    errdialog.run()
    return

  def create_id_foto(self, image, photo_size, face_size, to_head):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    # В этом словаре хранятся размеры в миллиметрах
    # и соответствующие им размеры в пикселях (при разрешении 600ppi)
    size_mode = {'30x40': [709, 945],
                 '35x45': [837, 1063],
                 '37x47': [875, 1111],
                 '40x60': [946, 1418],
                 '90x120': [2126, 2835],
                 '100x150': [2363, 3545],
                 '150x100': [3545, 2363],
                }

    hguide_list = [] # В этом списке хранятся координаты горионтальных направляющих
    vguide_list = [] # В этом списке хранятся координаты вертикальных направляющих

    # Находим направляющие, узнием их тип (вертикальная/горизонтальная)
    # и руководствуясь им заносим координаты в соответствующий список
    guide_id = 0
    guide_id = image.find_next_guide(guide_id)
    
    if guide_id == 0:
      self.show_error_msg("Нет ни одной направляющей. Поместите одну горизонтальную направляющую на уровне верхней частиголовы, одну горизонтальную напрвляющую на уровне глаз и одну на уровне подбородка, затем поставьте одну вертикальную направляющую на линию симметрии лица (порядок не важен, начинайте с любой направляющей)")
      image.undo_group_end()
      gimp.quit()
    else:
      while guide_id != 0:
        if image.get_guide_orientation(guide_id) == 0:
          hguide_list.append(image.get_guide_position(guide_id))
        else:
          vguide_list.append(image.get_guide_position(guide_id))
        guide_id = image.find_next_guide(guide_id)
        
    if len(hguide_list) != 3:
      self.show_error_msg("Горизонтальных направляющих должно быть три.")
      image.undo_group_end()
      gimp.quit()
    elif len(vguide_list) < 1:
      self.show_error_msg("Нет вертикальной направляющей.")
      image.undo_group_end()
      gimp.quit()
    elif len(vguide_list) > 1:
      self.show_error_msg("Должна быть только одна вертикальная направляющая.")
      image.undo_group_end()
      gimp.quit()

    # Пользователь может расставить направляющие в любой последовательности,
    # чтобы направляющие расположились в той последовательности, которая нужна нам
    # отсортируем список
    hguide_list.sort()
    
    # Узнаем размер лицевой части головы
    # и руководствуясь им вычисляем размеры холста
    k = hguide_list[2] - hguide_list[1] # Размер лица
    w = round((size_mode[photo_size][0] * k) / (face_size * 24)) # Ширина холста
    h = round((size_mode[photo_size][1] * k) / (face_size * 24)) # Высота холста
    x = (w / 2) - vguide_list[0] # Расстояние на которое будет смещен холст по оси X
    y = round(((to_head * 24) * k) / (face_size * 24)) - hguide_list[0] # Расстояние на которое будет смещен холст по оси Y
    # Изменяем размер холста и смещаем его
    image.resize(int(w), int(h), int(x), int(y))

    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на цвет индикатор
    gimp.set_background(113, 255, 0)
    # Сводим изображение
    image.flatten()
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Меняем разрешение до необходимого нам
    image.resolution = (600.0, 600.0)
    # Меняем размеры
    image.scale(size_mode[photo_size][0], size_mode[photo_size][1])
    
    # Удаляем все направляющие
    guide_id = 0
    guide_id = image.find_next_guide(guide_id)
    while guide_id != 0:
      image.delete_guide(guide_id)
      guide_id = image.find_next_guide(0)

    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  def gray_frame(self, image):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    # Увеличиваем размер холста
    image.resize(image.width + 2, image.height + 2, 1, 1)
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона
    gimp.set_background(125, 125, 125)
    # Сводим изображение
    image.flatten()
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
  def to_grayscale(self, image):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    # Конвертируем в оттенки серого
    pdb.gimp_image_convert_grayscale(image)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()

  def angle(self, image, drawable, type):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    if type == 'right_circular':
      # Выделяем область в виде элипса в углу изображения
      pdb.gimp_ellipse_select(image,               # Идентификатор изображения
                              (image.width - 440), # Кордината начальной точки выделения по оси X
                              (image.height - 346),# Кордината начальной точки выделения по оси Y
                              1080,                # Ширина элипса
                              1080,                # Высота элипса
                              CHANNEL_OP_REPLACE,  # Заменить текущее выделение
                              True,                # Сглажывать
                              True,                # Растушевать края
                              2)                   # Радиус растушовки

    elif type == 'left_circular':
      pdb.gimp_ellipse_select(image,
                              -644,
                              (image.height - 355),
                              1080,
                              1080,
                              CHANNEL_OP_REPLACE,
                              True,
                              True,
                              2)

    elif type == 'right_direct':

      points = [ image.width, (image.height - 338), # Координаты первой точки x1, y1
                 image.width, image.height,         # Координаты второй точки x2, y2
                 (image.width - 402), image.height ]# Координаты третьей точки x3, y3

      pdb.gimp_free_select(image,              # Идентификатор изображения
                           6,                  # Непонятный параметр
                           points,             # Массив с точками через которые пройдет линия выдеения
                           CHANNEL_OP_REPLACE, # Заменить текущее выделение
                           True,               # Сглажывать
                           True,               # Растушевать края
                           2)                  # Радиус растушовки
      
    elif type == 'left_direct':

      points = [ 0, (image.height - 338),
                 0, image.height,
                 402, image.height ]

      pdb.gimp_free_select(image,
                           6,
                           points,
                           CHANNEL_OP_REPLACE,
                           True,
                           True,
                           2)

    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Удаляем ранее выделеную область
    pdb.gimp_edit_clear(drawable)
    # Снимаем выделение
    pdb.gimp_selection_none(image)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
  def print_4_photo(self, image, drawable):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()
    # Изменяем размер холста до размеров 100x150 мм
    image.resize(2363, 3545, 0, 0)
    # Добавляем в изображение слой, который будет играть роль фона
    if drawable.is_rgb:
      white_bg = gimp.Layer(image, "Белый фон", 2363, 3545, RGB_IMAGE, 100, NORMAL_MODE)
    else:
      white_bg = gimp.Layer(image, "Белый фон", 2363, 3545, GRAY_IMAGE, 100, NORMAL_MODE)
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Заливаем слой цветом фона
    white_bg.fill(BACKGROUND_FILL)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Встраиваем новый слой в изображение
    image.add_layer(white_bg, 0)
    
    # Слой с челловеком оказался внизу, поэтому переместим его наверх
    image.raise_layer_to_top(drawable)
    # И поменяем ему имя
    drawable.name = "Копия 1"
    
    # Скопируем несколько раз и сместим копии
    layer_new2 = drawable.copy()
    layer_new2.name = "Копия 2"
    
    layer_new3 = drawable.copy()
    layer_new3.name = "Копия 3"
    
    layer_new4 = drawable.copy()
    layer_new4.name = "Копия 4"
    
    image.add_layer(layer_new2, 0)
    image.add_layer(layer_new3, 0)
    image.add_layer(layer_new4, 0)
    
    drawable.translate(120, 50)
    layer_new2.translate((layer_new2.width + 120 + 120), 50)
    layer_new3.translate(120, (layer_new3.height + 100))
    layer_new4.translate((layer_new4.width + 120 + 120), (layer_new4.height + 100))
    
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
    # Печатаем изображение на дефолтном принтере
    #pdb.file_print_gtk(image)
    
  def print_6_photo(self, image, drawable):
    gimp.context_push()
    # Запрещаем запись информации UNDO
    image.undo_group_start()

    # Изменяем размер холста до размеров 100x150мм
    image.resize(2363, 3545, 0, 0)
    # Добавляем в изображение слой, который будет играть роль фона
    if drawable.is_rgb:
      white_bg = gimp.Layer(image, "Белый фон", 2363, 3545, RGB_IMAGE, 100, NORMAL_MODE)
    else:
      white_bg = gimp.Layer(image, "Белый фон", 2363, 3545, GRAY_IMAGE, 100, NORMAL_MODE)
    # Запоминаем цвет фона
    old_background = gimp.get_background()
    # Меняем цвет фона на белый
    gimp.set_background(256, 256, 256)
    # Заливаем слой цветом фона
    white_bg.fill(BACKGROUND_FILL)
    # Возвращаем в исходное состояние цвет фона
    gimp.set_background(old_background)
    # Встраиваем новый слой в изображение
    image.add_layer(white_bg, 0)
    
    # Слой с челловеком оказался внизу, поэтому переместим его наверх
    image.raise_layer_to_top(drawable)
    # И поменяем ему имя
    drawable.name = "Копия 1"
    
    # Скопируем несколько раз и сместим копии
    layer_new2 = drawable.copy()
    layer_new2.name = "Копия 2"
    
    layer_new3 = drawable.copy()
    layer_new3.name = "Копия 3"
    
    layer_new4 = drawable.copy()
    layer_new4.name = "Копия 4"
    
    layer_new5 = drawable.copy()
    layer_new5.name = "Копия 5"
    
    layer_new6 = drawable.copy()
    layer_new6.name = "Копия 6"
    
    image.add_layer(layer_new2, 0)
    image.add_layer(layer_new3, 0)
    image.add_layer(layer_new4, 0)
    image.add_layer(layer_new5, 0)
    image.add_layer(layer_new6, 0)
    
    drawable.translate(120, 50)
    layer_new2.translate((layer_new2.width + 120 + 120), 50)
    layer_new3.translate(120, (layer_new3.height + 100))
    layer_new4.translate((layer_new4.width + 120 + 120), (layer_new4.height + 100))
    layer_new5.translate(120, (layer_new5.height + layer_new5.height + 150))
    layer_new6.translate((layer_new4.width + 120 + 120), (layer_new5.height + layer_new5.height + 150))
    
    # Обновляем изоборажение на дисплее
    gimp.displays_flush()
    # Разрешаем запись информации UNDO
    image.undo_group_end()
    gimp.context_pop()
    
    # Печатаем изображение на дефолтном принтере
    #pdb.file_print_gtk(image)

class id_photo_30x40(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.create_id_foto(image, '30x40', 11, 4)
    
class id_photo_35x45(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.create_id_foto(image, '35x45', 12, 5)
    
class id_photo_37x47(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.create_id_foto(image, '37x47', 12, 6)
    
class id_photo_40x60(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.create_id_foto(image, '40x60', 12, 5)
    
class id_photo_90x120(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.create_id_foto(image, '90x120', 23, 10)
    
class convert_to_grayscale(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.to_grayscale(image)

class create_gray_frame(id_photo_base):
  def __init__(self, runmode, image):
    self.image = image
    self.gray_frame(image)

class create_angle_right_circular(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.angle(image, drawable, 'right_circular')
    
class create_angle_left_circular(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.angle(image, drawable, 'left_circular')
    
class create_angle_right_direct(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.angle(image, drawable, 'right_direct')
    
class create_angle_left_direct(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.angle(image, drawable, 'left_direct')
    
class print_4_id_photo(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.print_4_photo(image, drawable)
    
class print_6_id_photo(id_photo_base):
  def __init__(self, runmode, image, drawable):
    self.image = image
    self.drawable = drawable
    self.print_6_photo(image, drawable)

class id_photo_plugin(gimpplugin.plugin):
  def start(self):
    gimp.main(self.init, self.quit, self.query, self._run)

  def init(self):
    pass

  def quit(self):
    pass

  def query(self):
    authorname = "Карабанов александр (zend.karabanov@gmail.com)"
    copyrightname = "Карабанов Александр"
    imgmenupath = "<Image>/На документы/"
    imgmenupath_format = "<Image>/На документы/Формат/"
    imgmenupath_angle = "<Image>/На документы/Уголок/"
    imgmenupath_actions = "<Image>/На документы/Действия/"
    imgmenupath_print = "<Image>/На документы/Напечатать/"
    date = "27 января 2011 года"

    id_photo_30x40_description = "Руководствуясь контрольными точками формирует фото на документы  формата 30x40."
    id_photo_30x40_help = "Расставьте направляющие и вызовите эту функцию."
    id_photo_30x40_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_id_photo_30x40",
      id_photo_30x40_description,
      id_photo_30x40_help,
      authorname,
      copyrightname,
      date,
      "%s_30x40 мм" % (imgmenupath_format),
      "RGB*, GRAY*",
      PLUGIN,
      id_photo_30x40_params,
      []
    )
    
    id_photo_35x45_description = "Руководствуясь контрольными точками формирует фото на документы  формата 35x45."
    id_photo_35x45_help = "Расставьте направляющие и вызовите эту функцию."
    id_photo_35x45_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_id_photo_35x45",
      id_photo_35x45_description,
      id_photo_35x45_help,
      authorname,
      copyrightname,
      date,
      "%s_35x45 мм" % (imgmenupath_format),
      "RGB*, GRAY*",
      PLUGIN,
      id_photo_35x45_params,
      []
    )
    
    id_photo_37x47_description = "Руководствуясь контрольными точками формирует фото на документы  формата 37x47."
    id_photo_37x47_help = "Расставьте направляющие и вызовите эту функцию."
    id_photo_37x47_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_id_photo_37x47",
      id_photo_37x47_description,
      id_photo_37x47_help,
      authorname,
      copyrightname,
      date,
      "%s_37x47 мм" % (imgmenupath_format),
      "RGB*, GRAY*",
      PLUGIN,
      id_photo_37x47_params,
      []
    )

    id_photo_40x60_description = "Руководствуясь контрольными точками формирует фото на документы формата 40x60."
    id_photo_40x60_help = "Расставьте направляющие и вызовите эту функцию."
    id_photo_40x60_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_id_photo_40x60",
      id_photo_40x60_description,
      id_photo_40x60_help,
      authorname,
      copyrightname,
      date,
      "%s_40x60 мм" % (imgmenupath_format),
      "RGB*, GRAY*",
      PLUGIN,
      id_photo_40x60_params,
      []
    )
    
    id_photo_90x120_description = "Руководствуясь контрольными точками формирует фото на документы формата 90x120."
    id_photo_90x120_help = "Расставьте направляющие и вызовите эту функцию."
    id_photo_90x120_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_id_photo_90x120",
      id_photo_90x120_description,
      id_photo_90x120_help,
      authorname,
      copyrightname,
      date,
      "%s_90x120 мм" % (imgmenupath_format),
      "RGB*, GRAY*",
      PLUGIN,
      id_photo_90x120_params,
      []
    )
    
    gray_frame_description = "Рисует вокруг изображения серую однопиксельную рамку."
    gray_frame_help = "Нарисовать рамку."
    gray_frame_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_create_gray_frame",
      gray_frame_description,
      gray_frame_help,
      authorname,
      copyrightname,
      date,
      "%s_Рамка" % (imgmenupath_actions),
      "RGB*, GRAY*",
      PLUGIN,
      gray_frame_params,
      []
    )
    
    to_grayscale_description = "Конвертирует изображение в оттенки серого."
    to_grayscale_help = "Конвертировать в оттенки серого."
    to_grayscale_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение")
    )
    gimp.install_procedure(
      "python_convert_to_grayscale",
      to_grayscale_description,
      to_grayscale_help,
      authorname,
      copyrightname,
      date,
      "%s_Обесцветить" % (imgmenupath_actions),
      "RGB*, GRAY*",
      PLUGIN,
      to_grayscale_params,
      []
    )

    angle_right_circular_description = "Рисует круглый «уголок» в правом нижнем углу изображения."
    angle_right_circular_help = "Нарисовать «уголок»."
    angle_right_circular_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_create_angle_right_circular",
      angle_right_circular_description,
      angle_right_circular_help,
      authorname,
      copyrightname,
      date,
      "%s_Круглый справа" % (imgmenupath_angle),
      "RGB*, GRAY*",
      PLUGIN,
      angle_right_circular_params,
      []
    )
    
    angle_left_circular_description = "Рисует круглый «уголок» в левом нижнем углу изображения."
    angle_left_circular_help = "Нарисовать «уголок»."
    angle_left_circular_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_create_angle_left_circular",
      angle_left_circular_description,
      angle_left_circular_help,
      authorname,
      copyrightname,
      date,
      "%s_Круглый слева" % (imgmenupath_angle),
      "RGB*, GRAY*",
      PLUGIN,
      angle_left_circular_params,
      []
    )
    
    angle_right_direct_description = "Рисует прямой «уголок» в правом нижнем углу изображения."
    angle_right_direct_help = "Нарисовать «уголок»."
    angle_right_direct_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_create_angle_right_direct",
      angle_right_direct_description,
      angle_right_direct_help,
      authorname,
      copyrightname,
      date,
      "%s_Прямой справа" % (imgmenupath_angle),
      "RGB*, GRAY*",
      PLUGIN,
      angle_right_direct_params,
      []
    )
    
    angle_left_direct_description = "Рисует прямой «уголок» в левом нижнем углу изображения."
    angle_left_direct_help = "Нарисовать «уголок»."
    angle_left_direct_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_create_angle_left_direct",
      angle_left_direct_description,
      angle_left_direct_help,
      authorname,
      copyrightname,
      date,
      "%s_Прямой слева" % (imgmenupath_angle),
      "RGB*, GRAY*",
      PLUGIN,
      angle_left_direct_params,
      []
    )
    
    print_4_id_photo_description = "Накладывает на шаблон формата 100x150 мм 4 фото"
    print_4_id_photo_help = "Напечатать 4 фото."
    print_4_id_photo_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_print_4_id_photo",
      print_4_id_photo_description,
      print_4_id_photo_help,
      authorname,
      copyrightname,
      date,
      "%s_4 фото" % (imgmenupath),
      "RGB*, GRAY*",
      PLUGIN,
      print_4_id_photo_params,
      []
    )
    
    print_6_id_photo_description = "Накладывает на шаблон формата 100x150 мм 6 фото"
    print_6_id_photo_help = "Напечатать 6 фото."
    print_6_id_photo_params = (
      (PDB_INT32,    "run_mode", "Режим запуска (в данном случае бесполезная опция)"),
      (PDB_IMAGE,    "image",    "Исходное изображение"),
      (PDB_DRAWABLE, "drawable", "Активный слой")
    )
    gimp.install_procedure(
      "python_print_6_id_photo",
      print_6_id_photo_description,
      print_6_id_photo_help,
      authorname,
      copyrightname,
      date,
      "%s_6 фото" % (imgmenupath),
      "RGB*, GRAY*",
      PLUGIN,
      print_6_id_photo_params,
      []
    )

  def python_id_photo_30x40(
    self,
    runmode,
    image
  ):
    id_photo_30x40(runmode, image)
    
  def python_id_photo_35x45(
    self,
    runmode,
    image
  ):
    id_photo_35x45(runmode, image)
    
  def python_id_photo_37x47(
    self,
    runmode,
    image
  ):
    id_photo_37x47(runmode, image)
    
  def python_id_photo_40x60(
    self,
    runmode,
    image
  ):
    id_photo_40x60(runmode, image)
    
  def python_id_photo_90x120(
    self,
    runmode,
    image
  ):
    id_photo_90x120(runmode, image)

  def python_create_gray_frame(
    self,
    runmode,
    image
  ):
    create_gray_frame(runmode, image)
    
  def python_convert_to_grayscale(
    self,
    runmode,
    image
  ):
    convert_to_grayscale(runmode, image)

  def python_create_angle_right_circular(
    self,
    runmode,
    image,
    drawable
  ):
    create_angle_right_circular(runmode, image, drawable)
    
  def python_create_angle_left_circular(
    self,
    runmode,
    image,
    drawable
  ):
    create_angle_left_circular(runmode, image, drawable)
    
  def python_create_angle_right_direct(
    self,
    runmode,
    image,
    drawable
  ):
    create_angle_right_direct(runmode, image, drawable)
    
  def python_create_angle_left_direct(
    self,
    runmode,
    image,
    drawable
  ):
    create_angle_left_direct(runmode, image, drawable)
    
  def python_print_4_id_photo(
    self,
    runmode,
    image,
    drawable
  ):
    print_4_id_photo(runmode, image, drawable)
    
  def python_print_6_id_photo(
    self,
    runmode,
    image,
    drawable
  ):
    print_6_id_photo(runmode, image, drawable)


if __name__ == "__main__":
  id_photo_plugin().start()
